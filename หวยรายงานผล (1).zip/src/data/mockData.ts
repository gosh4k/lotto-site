import { LotteryResult, LotteryPeriod } from '../types/lottery';

export const lotteryResults: LotteryResult[] = [
  {
    id: 1,
    date: '16 มิถุนายน 2568',
    firstPrize: '123456',
    firstThreeDigits: ['123', '234'],
    lastThreeDigits: ['567', '678'],
    lastTwoDigits: '89',
  },
  {
    id: 2,
    date: '1 มิถุนายน 2568',
    firstPrize: '876543',
    firstThreeDigits: ['345', '456'],
    lastThreeDigits: ['789', '890'],
    lastTwoDigits: '12',
  },
  {
    id: 3,
    date: '16 พฤษภาคม 2568',
    firstPrize: '654321',
    firstThreeDigits: ['567', '678'],
    lastThreeDigits: ['901', '012'],
    lastTwoDigits: '34',
  },
  {
    id: 4,
    date: '1 พฤษภาคม 2568',
    firstPrize: '246810',
    firstThreeDigits: ['789', '890'],
    lastThreeDigits: ['123', '234'],
    lastTwoDigits: '56',
  },
  {
    id: 5,
    date: '16 เมษายน 2568',
    firstPrize: '135792',
    firstThreeDigits: ['901', '012'],
    lastThreeDigits: ['345', '456'],
    lastTwoDigits: '78',
  },
];

export const lotteryPeriods: LotteryPeriod[] = [
  { id: 1, date: '16 มิถุนายน 2568', displayText: 'งวดวันที่ 16 มิถุนายน 2568' },
  { id: 2, date: '1 มิถุนายน 2568', displayText: 'งวดวันที่ 1 มิถุนายน 2568' },
  { id: 3, date: '16 พฤษภาคม 2568', displayText: 'งวดวันที่ 16 พฤษภาคม 2568' },
  { id: 4, date: '1 พฤษภาคม 2568', displayText: 'งวดวันที่ 1 พฤษภาคม 2568' },
  { id: 5, date: '16 เมษายน 2568', displayText: 'งวดวันที่ 16 เมษายน 2568' },
];
