import { HashRouter, Route, Routes } from 'react-router'
import Home from './pages/Home'
import RewardCheck from './pages/RewardCheck'

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/reward-check" element={<RewardCheck />} />
      </Routes>
    </HashRouter>
  )
}
