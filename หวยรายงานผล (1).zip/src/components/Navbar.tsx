import { Search } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router';

interface NavbarProps {
  onSearch: (query: string) => void;
}

export default function Navbar({ onSearch }: NavbarProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  return (
    <nav className="bg-gradient-to-r from-amber-800 via-amber-700 to-amber-800 text-white py-4 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="h-14 w-14 mr-3 rounded-full overflow-hidden border-2 border-yellow-300 shadow-lg">
              <img 
                src="https://pub-cdn.sider.ai/u/U06XHN9OKY1/web-coder/684e87e5060d7d85c71ca9e0/resource/42ecaa40-1e36-4f5a-ad82-16486078e015.jpg" 
                alt="บ้านมิ่งมงคล" 
                className="object-cover h-full w-full" 
              />
            </div>
            <div>
              <Link to="/" className="text-2xl font-bold text-yellow-300">บ้านมิ่งมงคล</Link>
              <p className="text-yellow-100 text-xs">ตรวจผลรางวัลสลากกินแบ่งรัฐบาล</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 w-full md:w-auto justify-between">
            <div className="flex space-x-4">
              <Link to="/" className="hover:text-yellow-200 font-medium">หน้าแรก</Link>
              <Link to="/reward-check" className="hover:text-yellow-200 font-medium">ตรวจผลรางวัล</Link>
            </div>
            
            <form onSubmit={handleSearch} className="flex w-full md:w-auto ml-4">
              <input
                type="text"
                placeholder="ค้นหาเลขหวย..."
                className="px-4 py-2 rounded-l-md focus:outline-none text-black w-full md:w-64"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button
                type="submit"
                className="bg-yellow-500 hover:bg-yellow-600 px-4 py-2 rounded-r-md text-white"
              >
                <Search size={20} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </nav>
  );
}
