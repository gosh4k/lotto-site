import { useState } from 'react';
import { LotteryPeriod } from '../types/lottery';
import { ChevronDown } from 'lucide-react';

interface PeriodSelectorProps {
  periods: LotteryPeriod[];
  currentPeriodId: number;
  onPeriodChange: (periodId: number) => void;
}

export default function PeriodSelector({ periods, currentPeriodId, onPeriodChange }: PeriodSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const currentPeriod = periods.find(period => period.id === currentPeriodId);

  return (
    <div className="relative mb-6">
      <button
        className="w-full bg-amber-700 hover:bg-amber-800 text-white font-medium py-3 px-4 rounded-md flex items-center justify-between shadow-md"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span>{currentPeriod?.displayText || 'เลือกงวด'}</span>
        <ChevronDown size={20} className={`transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute z-10 mt-1 w-full bg-white rounded-md shadow-lg max-h-60 overflow-auto">
          {periods.map((period) => (
            <button
              key={period.id}
              className={`w-full text-left px-4 py-3 hover:bg-amber-50 transition-colors ${
                period.id === currentPeriodId ? 'bg-amber-100 font-medium' : ''
              }`}
              onClick={() => {
                onPeriodChange(period.id);
                setIsOpen(false);
              }}
            >
              {period.displayText}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
