export default function Footer() {
  return (
    <footer className="bg-gradient-to-r from-amber-900 via-amber-800 to-amber-900 text-white py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-bold text-yellow-300 mb-2">บ้านมิ่งมงคล</h2>
            <p className="text-sm text-gray-300">
              เว็บไซต์นี้สร้างขึ้นเพื่อแสดงผลการออกรางวัลสลากกินแบ่งรัฐบาลเท่านั้น
            </p>
          </div>
          <div className="text-center md:text-right">
            <p className="text-sm text-gray-300">
              © {new Date().getFullYear()} บ้านมิ่งมงคล
            </p>
            <p className="text-sm text-gray-300 mt-1">
              สงวนลิขสิทธิ์ตามกฎหมาย
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
