import { useState } from 'react';
import { LotteryResult } from '../types/lottery';
import { Search } from 'lucide-react';

interface NumberCheckerProps {
  currentResult: LotteryResult;
}

export default function NumberChecker({ currentResult }: NumberCheckerProps) {
  const [number, setNumber] = useState('');
  const [checkResult, setCheckResult] = useState<{
    hasResult: boolean;
    prize: string | null;
    message: string;
  } | null>(null);

  const checkNumber = (e: React.FormEvent) => {
    e.preventDefault();

    if (!number || number.length < 2) {
      setCheckResult({
        hasResult: false,
        prize: null,
        message: 'กรุณาใส่เลขอย่างน้อย 2 หลัก',
      });
      return;
    }

    // Check first prize
    if (number === currentResult.firstPrize) {
      setCheckResult({
        hasResult: true,
        prize: 'รางวัลที่ 1',
        message: 'ยินดีด้วย! คุณถูกรางวัลที่ 1',
      });
      return;
    }

    // Check first three digits
    if (number.length >= 3) {
      const firstThree = number.substring(0, 3);
      if (currentResult.firstThreeDigits.includes(firstThree)) {
        setCheckResult({
          hasResult: true,
          prize: 'เลขหน้า 3 ตัว',
          message: 'ยินดีด้วย! คุณถูกรางวัลเลขหน้า 3 ตัว',
        });
        return;
      }
    }

    // Check last three digits
    if (number.length >= 3) {
      const lastThree = number.slice(-3);
      if (currentResult.lastThreeDigits.includes(lastThree)) {
        setCheckResult({
          hasResult: true,
          prize: 'เลขท้าย 3 ตัว',
          message: 'ยินดีด้วย! คุณถูกรางวัลเลขท้าย 3 ตัว',
        });
        return;
      }
    }

    // Check last two digits
    if (number.length >= 2) {
      const lastTwo = number.slice(-2);
      if (lastTwo === currentResult.lastTwoDigits) {
        setCheckResult({
          hasResult: true,
          prize: 'เลขท้าย 2 ตัว',
          message: 'ยินดีด้วย! คุณถูกรางวัลเลขท้าย 2 ตัว',
        });
        return;
      }
    }

    // No prize
    setCheckResult({
      hasResult: true,
      prize: null,
      message: 'เสียใจด้วย ไม่ถูกรางวัล',
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6 border-t-4 border-amber-600">
      <h3 className="text-xl font-semibold mb-4 text-center text-amber-800">ตรวจเลขรางวัล</h3>
      <p className="text-amber-600 mb-4 text-center">งวดวันที่ {currentResult.date}</p>

      <form onSubmit={checkNumber} className="mb-6">
        <div className="flex items-center border-2 border-amber-200 rounded-md overflow-hidden">
          <input
            type="text"
            className="w-full px-4 py-3 focus:outline-none text-lg"
            placeholder="กรอกเลขสลาก 2-6 หลัก"
            value={number}
            onChange={(e) => {
              const value = e.target.value;
              if (/^\d*$/.test(value) && value.length <= 6) {
                setNumber(value);
              }
            }}
          />
          <button
            type="submit"
            className="bg-amber-700 hover:bg-amber-800 text-white px-4 py-3"
          >
            <Search size={24} />
          </button>
        </div>
      </form>

      {checkResult && (
        <div
          className={`text-center p-4 rounded-md ${
            checkResult.prize
              ? 'bg-green-100 border-2 border-green-300 text-green-800'
              : 'bg-gray-100 border-2 border-gray-300 text-gray-800'
          }`}
        >
          <p className="text-xl font-medium mb-2">{checkResult.message}</p>
          {checkResult.prize && (
            <p className="text-lg">
              รางวัล: <span className="font-bold">{checkResult.prize}</span>
            </p>
          )}
        </div>
      )}
    </div>
  );
}
