import { LotteryResult } from '../types/lottery';

interface LotteryResultDisplayProps {
  result: LotteryResult;
}

export default function LotteryResultDisplay({ result }: LotteryResultDisplayProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6 border-t-4 border-amber-600">
      <div className="text-center mb-6">
        <h2 className="text-xl font-semibold mb-1 text-amber-800">ผลสลากกินแบ่งรัฐบาล</h2>
        <p className="text-amber-600">{result.date}</p>
      </div>

      <div className="mb-8">
        <h3 className="text-center text-lg font-medium mb-3 bg-amber-700 text-white py-2 rounded-md">รางวัลที่ 1</h3>
        <div className="flex justify-center">
          <div className="bg-amber-50 border-2 border-amber-400 rounded-lg px-8 py-6">
            <p className="text-4xl md:text-6xl font-bold text-red-700 tracking-wider">{result.firstPrize}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="text-center text-lg font-medium mb-3 bg-amber-700 text-white py-2 rounded-md">เลขหน้า 3 ตัว</h3>
          <div className="grid grid-cols-2 gap-4">
            {result.firstThreeDigits.map((digit, index) => (
              <div key={index} className="bg-amber-50 border-2 border-amber-300 rounded-lg py-3 text-center">
                <p className="text-2xl md:text-3xl font-bold text-red-600">{digit}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-center text-lg font-medium mb-3 bg-amber-700 text-white py-2 rounded-md">เลขท้าย 3 ตัว</h3>
          <div className="grid grid-cols-2 gap-4">
            {result.lastThreeDigits.map((digit, index) => (
              <div key={index} className="bg-amber-50 border-2 border-amber-300 rounded-lg py-3 text-center">
                <p className="text-2xl md:text-3xl font-bold text-red-600">{digit}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-center text-lg font-medium mb-3 bg-amber-700 text-white py-2 rounded-md">เลขท้าย 2 ตัว</h3>
        <div className="flex justify-center">
          <div className="bg-amber-50 border-2 border-amber-300 rounded-lg px-12 py-4 text-center">
            <p className="text-3xl md:text-4xl font-bold text-red-600">{result.lastTwoDigits}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
