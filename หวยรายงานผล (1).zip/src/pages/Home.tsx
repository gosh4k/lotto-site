import { useState } from 'react';
import Navbar from '../components/Navbar';
import LotteryResultDisplay from '../components/LotteryResultDisplay';
import PeriodSelector from '../components/PeriodSelector';
import NumberChecker from '../components/NumberChecker';
import Footer from '../components/Footer';
import { lotteryResults, lotteryPeriods } from '../data/mockData';

export default function Home() {
  const [currentPeriodId, setCurrentPeriodId] = useState(1); // Default to latest period
  const [searchTerm, setSearchTerm] = useState('');

  const currentResult = lotteryResults.find(result => result.id === currentPeriodId) || lotteryResults[0];

  const handleSearch = (query: string) => {
    setSearchTerm(query);
    
    // If search query matches a lottery number, show relevant message
    if (query.length > 0) {
      // Implementation would depend on your search requirements
      console.log(`Searching for: ${query}`);
      // For now, just clear the search after 3 seconds
      setTimeout(() => setSearchTerm(''), 3000);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-amber-50">
      <Navbar onSearch={handleSearch} />
      
      <div className="w-full bg-gradient-to-r from-amber-800 via-amber-700 to-amber-800 py-6 px-4 text-center text-white">
        <h1 className="text-3xl font-bold text-yellow-300 mb-2">บ้านมิ่งมงคล</h1>
        <p className="text-xl text-yellow-100">ตรวจผลรางวัลสลากกินแบ่งรัฐบาล</p>
      </div>
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <PeriodSelector 
              periods={lotteryPeriods} 
              currentPeriodId={currentPeriodId} 
              onPeriodChange={setCurrentPeriodId} 
            />
            <LotteryResultDisplay result={currentResult} />
          </div>
          
          <div>
            <NumberChecker currentResult={currentResult} />
            
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-semibold mb-4 text-center text-amber-800">สถิติหวยย้อนหลัง</h3>
              <div className="space-y-4">
                {lotteryResults.slice(0, 5).map(result => (
                  <div key={result.id} className="border-b border-amber-100 pb-3 last:border-0">
                    <p className="font-medium text-amber-900">{result.date}</p>
                    <div className="flex justify-between mt-2">
                      <span className="text-amber-700">รางวัลที่ 1:</span>
                      <span className="font-bold text-red-600">{result.firstPrize}</span>
                    </div>
                    <div className="flex justify-between mt-1">
                      <span className="text-amber-700">เลขท้าย 2 ตัว:</span>
                      <span className="font-bold text-red-600">{result.lastTwoDigits}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
