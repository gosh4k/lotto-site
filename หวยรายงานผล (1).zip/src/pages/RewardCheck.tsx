import { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { lotteryResults, lotteryPeriods } from '../data/mockData';
import { LotteryResult } from '../types/lottery';
import { ChevronDown, Search, CalendarDays } from 'lucide-react';

export default function RewardCheck() {
  const [selectedPeriod, setSelectedPeriod] = useState<number>(1);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchNumber, setSearchNumber] = useState('');
  const [searchResults, setSearchResults] = useState<{
    firstPrize: boolean;
    firstThreeDigits: boolean;
    lastThreeDigits: boolean;
    lastTwoDigits: boolean;
  } | null>(null);
  
  const currentResult = lotteryResults.find(result => result.id === selectedPeriod) || lotteryResults[0];
  const currentPeriod = lotteryPeriods.find(period => period.id === selectedPeriod);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchNumber || searchNumber.length < 2) {
      alert('กรุณากรอกเลขอย่างน้อย 2 หลัก');
      return;
    }
    
    checkLotteryNumber(searchNumber, currentResult);
  };
  
  const checkLotteryNumber = (number: string, lotteryResult: LotteryResult) => {
    const results = {
      firstPrize: number === lotteryResult.firstPrize,
      firstThreeDigits: number.length >= 3 && lotteryResult.firstThreeDigits.includes(number.substring(0, 3)),
      lastThreeDigits: number.length >= 3 && lotteryResult.lastThreeDigits.includes(number.slice(-3)),
      lastTwoDigits: number.length >= 2 && lotteryResult.lastTwoDigits === number.slice(-2)
    };
    
    setSearchResults(results);
  };

  return (
    <div className="min-h-screen flex flex-col bg-amber-50">
      <Navbar onSearch={() => {}} />
      
      <div className="w-full bg-gradient-to-r from-amber-800 via-amber-700 to-amber-800 py-6 px-4 text-center text-white">
        <h1 className="text-3xl font-bold text-yellow-300 mb-2">บ้านมิ่งมงคล</h1>
        <p className="text-xl text-yellow-100">ตรวจผลรางวัลสลากกินแบ่งรัฐบาล</p>
      </div>
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6 border-t-4 border-amber-600">
          <h1 className="text-2xl font-bold text-center text-amber-800 mb-6">ตรวจผลรางวัลสลากกินแบ่งรัฐบาล</h1>
          
          <div className="mb-8">
            {/* Period Selector */}
            <div className="relative mb-6">
              <label className="block text-amber-800 font-medium mb-2">เลือกงวดที่ต้องการตรวจ</label>
              <button
                className="w-full bg-white border-2 border-amber-200 hover:border-amber-300 text-gray-800 font-medium py-3 px-4 rounded-md flex items-center justify-between"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              >
                <div className="flex items-center">
                  <CalendarDays size={20} className="mr-2 text-amber-600" />
                  <span>{currentPeriod?.displayText || 'เลือกงวด'}</span>
                </div>
                <ChevronDown size={20} className={`transition-transform text-amber-600 ${isDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {isDropdownOpen && (
                <div className="absolute z-10 mt-1 w-full bg-white rounded-md shadow-lg max-h-60 overflow-auto border border-amber-200">
                  {lotteryPeriods.map((period) => (
                    <button
                      key={period.id}
                      className={`w-full text-left px-4 py-3 hover:bg-amber-50 transition-colors ${
                        period.id === selectedPeriod ? 'bg-amber-100 font-medium' : ''
                      }`}
                      onClick={() => {
                        setSelectedPeriod(period.id);
                        setIsDropdownOpen(false);
                        setSearchResults(null);
                      }}
                    >
                      {period.displayText}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Search Form */}
            <div>
              <label className="block text-amber-800 font-medium mb-2">กรอกเลขสลากที่ต้องการตรวจ</label>
              <form onSubmit={handleSearch} className="mb-6">
                <div className="flex items-center border-2 border-amber-200 rounded-md overflow-hidden">
                  <input
                    type="text"
                    className="w-full px-4 py-3 focus:outline-none text-lg"
                    placeholder="กรอกเลขสลาก 2-6 หลัก"
                    value={searchNumber}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (/^\d*$/.test(value) && value.length <= 6) {
                        setSearchNumber(value);
                      }
                    }}
                  />
                  <button
                    type="submit"
                    className="bg-amber-700 hover:bg-amber-800 text-white px-6 py-3"
                  >
                    <div className="flex items-center">
                      <Search size={20} className="mr-2" />
                      <span>ตรวจรางวัล</span>
                    </div>
                  </button>
                </div>
              </form>
            </div>
            
            {/* Search Results */}
            {searchResults && (
              <div className="mt-8">
                <h2 className="text-xl font-semibold mb-4 text-center text-amber-800">ผลการตรวจรางวัล</h2>
                <p className="text-center text-amber-600 mb-6">
                  ตรวจเลข <span className="font-bold text-red-600">{searchNumber}</span> งวดวันที่ {currentResult.date}
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className={`p-4 rounded-md border-2 ${searchResults.firstPrize ? 'bg-green-100 border-green-300' : 'bg-gray-100 border-gray-300'}`}>
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium">รางวัลที่ 1</h3>
                      <span className={`font-bold ${searchResults.firstPrize ? 'text-green-600' : 'text-gray-500'}`}>
                        {searchResults.firstPrize ? 'ถูกรางวัล' : 'ไม่ถูกรางวัล'}
                      </span>
                    </div>
                    <p className="mt-2 text-gray-600">รางวัลละ 6,000,000 บาท</p>
                  </div>
                  
                  <div className={`p-4 rounded-md border-2 ${searchResults.firstThreeDigits ? 'bg-green-100 border-green-300' : 'bg-gray-100 border-gray-300'}`}>
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium">เลขหน้า 3 ตัว</h3>
                      <span className={`font-bold ${searchResults.firstThreeDigits ? 'text-green-600' : 'text-gray-500'}`}>
                        {searchResults.firstThreeDigits ? 'ถูกรางวัล' : 'ไม่ถูกรางวัล'}
                      </span>
                    </div>
                    <p className="mt-2 text-gray-600">รางวัลละ 4,000 บาท</p>
                  </div>
                  
                  <div className={`p-4 rounded-md border-2 ${searchResults.lastThreeDigits ? 'bg-green-100 border-green-300' : 'bg-gray-100 border-gray-300'}`}>
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium">เลขท้าย 3 ตัว</h3>
                      <span className={`font-bold ${searchResults.lastThreeDigits ? 'text-green-600' : 'text-gray-500'}`}>
                        {searchResults.lastThreeDigits ? 'ถูกรางวัล' : 'ไม่ถูกรางวัล'}
                      </span>
                    </div>
                    <p className="mt-2 text-gray-600">รางวัลละ 4,000 บาท</p>
                  </div>
                  
                  <div className={`p-4 rounded-md border-2 ${searchResults.lastTwoDigits ? 'bg-green-100 border-green-300' : 'bg-gray-100 border-gray-300'}`}>
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium">เลขท้าย 2 ตัว</h3>
                      <span className={`font-bold ${searchResults.lastTwoDigits ? 'text-green-600' : 'text-gray-500'}`}>
                        {searchResults.lastTwoDigits ? 'ถูกรางวัล' : 'ไม่ถูกรางวัล'}
                      </span>
                    </div>
                    <p className="mt-2 text-gray-600">รางวัลละ 2,000 บาท</p>
                  </div>
                </div>
                
                {/* Summary */}
                <div className="mt-8 p-6 bg-amber-50 rounded-lg border border-amber-200">
                  <h3 className="text-xl font-bold text-center mb-4 text-amber-800">สรุปผลการตรวจรางวัล</h3>
                  {(searchResults.firstPrize || searchResults.firstThreeDigits || 
                    searchResults.lastThreeDigits || searchResults.lastTwoDigits) ? (
                    <div className="text-center">
                      <p className="text-green-600 font-bold text-xl mb-2">ยินดีด้วย! คุณถูกรางวัล</p>
                      <ul className="mt-4 space-y-2">
                        {searchResults.firstPrize && <li className="font-medium">✓ รางวัลที่ 1 มูลค่า 6,000,000 บาท</li>}
                        {searchResults.firstThreeDigits && <li className="font-medium">✓ เลขหน้า 3 ตัว มูลค่า 4,000 บาท</li>}
                        {searchResults.lastThreeDigits && <li className="font-medium">✓ เลขท้าย 3 ตัว มูลค่า 4,000 บาท</li>}
                        {searchResults.lastTwoDigits && <li className="font-medium">✓ เลขท้าย 2 ตัว มูลค่า 2,000 บาท</li>}
                      </ul>
                    </div>
                  ) : (
                    <p className="text-center text-gray-700 font-medium">เสียใจด้วย คุณไม่ถูกรางวัลในงวดนี้</p>
                  )}
                </div>
              </div>
            )}
          </div>
          
          {/* Current Results Summary */}
          <div className="mt-8 pt-6 border-t border-amber-200">
            <h2 className="text-xl font-semibold mb-4 text-amber-800">ผลรางวัลงวดวันที่ {currentResult.date}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-amber-50 p-4 rounded-lg border-2 border-amber-300">
                <h3 className="text-center font-medium mb-2 text-amber-800">รางวัลที่ 1</h3>
                <p className="text-center font-bold text-2xl text-red-700">{currentResult.firstPrize}</p>
              </div>
              <div className="bg-amber-50 p-4 rounded-lg border-2 border-amber-300">
                <h3 className="text-center font-medium mb-2 text-amber-800">เลขหน้า 3 ตัว</h3>
                <div className="flex justify-center gap-2">
                  {currentResult.firstThreeDigits.map((digit, idx) => (
                    <p key={idx} className="font-bold text-xl text-red-700">{digit}</p>
                  ))}
                </div>
              </div>
              <div className="bg-amber-50 p-4 rounded-lg border-2 border-amber-300">
                <h3 className="text-center font-medium mb-2 text-amber-800">เลขท้าย 3 ตัว</h3>
                <div className="flex justify-center gap-2">
                  {currentResult.lastThreeDigits.map((digit, idx) => (
                    <p key={idx} className="font-bold text-xl text-red-700">{digit}</p>
                  ))}
                </div>
              </div>
              <div className="bg-amber-50 p-4 rounded-lg border-2 border-amber-300">
                <h3 className="text-center font-medium mb-2 text-amber-800">เลขท้าย 2 ตัว</h3>
                <p className="text-center font-bold text-2xl text-red-700">{currentResult.lastTwoDigits}</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
