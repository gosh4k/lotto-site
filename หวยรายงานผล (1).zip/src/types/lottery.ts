export interface LotteryResult {
  id: number;
  date: string;
  firstPrize: string;
  firstThreeDigits: string[];
  lastThreeDigits: string[];
  lastTwoDigits: string;
}

export interface LotteryPeriod {
  id: number;
  date: string;
  displayText: string;
}
